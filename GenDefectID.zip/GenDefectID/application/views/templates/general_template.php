<?php $this->load->view('templates/general_header'); ?>
<?php $this->load->view($template); ?>
<?php $this->load->view('templates/general_footer'); ?>