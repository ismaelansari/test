<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"> 
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>GenDefectID:- <?php echo isset($title)?$title:''; ?></title>
<link rel="icon" href="<?php echo defaltPath; ?>images/ww_favicon.gif" type="image/gif" />
<link rel="stylesheet" type="text/css" href="<?php echo defaltPath; ?>css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="<?php echo defaltPath; ?>css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo defaltPath; ?>css/style.css">
<link rel="stylesheet" type="text/css" href="<?php echo defaltPath; ?>fonts/font-awesome.css">
</head>
<div class="container" id="home">
  <div class="row">
      <div ><img src="<?php echo defaltPath; ?>images/wise_working.png" width="344" height="110" alt="Wiseworking"></div>
    </div>
<div class="col-md-12 col-sm-12 col-xs-12" style="border-top:1px #CCCCCC solid;">&nbsp;</div>
